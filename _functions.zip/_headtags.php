<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PQ4QJ8B');</script>
<!-- End Google Tag Manager -->
<!-- Favicons -->
<link href="assets/img/favicon.png" rel="icon">
<!-- Google Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100&display=swap" rel="stylesheet">
<!-- Vendor CSS Files -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet">
<link href="assets/vendor/aos/aos.css" rel="stylesheet">
<link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
<link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
<!-- sweetalert CSS -->
<link rel="stylesheet" href="assets/vendor/sweetalert2/sweetalert2.min.css">
<!-- Sweetalert2 JS -->
<script src="assets/vendor/sweetalert2/sweetalert2.min.js"></script>

<!-- Style -->
<link rel="stylesheet" href="assets/carousel/css/style.css">
<link rel="stylesheet" href="assets/css/carousel.css">

<!-- Template Main CSS File -->
<link href="assets/css/style.css" rel="stylesheet">
<link href="assets/css/carousel.css" rel="stylesheet">

<link rel="stylesheet" href="assets/carousel/fonts/icomoon/style.css">
<link rel="stylesheet" href="assets/carousel/css/owl.carousel.min.css">
<meta content='assets/img/itdri.jpeg' property='og:image'/>