# ITDRI eCommerce Prototype

<br>
<p align="center"><img width="70%" src="https://pentahelix.net/wp-content/uploads/2021/01/ITDRI-LOGO-MAIN-PNG-1-300x169.png"></p>

### # MADE WITH

* PHP [`Click Here`](https://www.php.net/)
* Bootstrap v5.1 [`Click Here`](https://getbootstrap.com/)
* Sweetalert2 [`Click Here`](https://sweetalert2.github.io/)

### # MOCKUP UI UX

* Figma Mockup [`Click Here`](https://bit.ly/MockupDesainWeb-ITDRI)